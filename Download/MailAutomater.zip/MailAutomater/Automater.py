from openProgram import *
from WhiteList import *
from AddressBook import *
import ezgmail


def Run():
        Automation_Tasks_Unread = ezgmail.unread()
        for l in Automation_Tasks_Unread:
                j=l.messages[len(l.messages)-1]
                print(j)
                if (j.subject == "Automater"):
                    if (verAllow(midSplit(j.sender,"<", ">"), True)):
                        RawData = j.snippet
                        RawData = str(RawData)
                        RawData = RawData.split("|")
                        print(RawData)
                        match RawData[0].lower():
                            case "help":
                                ezgmail.send(j.sender, 'Registered', 'Automater Has These Special Commands Currently: \
                                             \n1. "openProgram|FileExtension(.XXX)|NameofProgram|InternalProgramming" \n*Syntax Rules for OpenPythonProgram*\n*The enter Key = "$"*\n*The Leave Single Loop Key = "$~"*\n*The Enter Single Loop Key = "$^"*\
                                             \n2. "Introduceperson|JohnDoe@EMail.com" (Have helper introduce itself) \
                                             \n3. "getAddress|InfoType["name","lastname","city","state","zip"]|Info"\
                                             \n4. "addAddress|firstname:lastname:address_line:city:state:zip_code"\
                                             \n5. "Allow|Email" (Puts specific email onto allow list)\
                                             \n6. "AdminAllow|Email" (Puts Email on AdminList)\
                                             \n7. "AdminAllow|PhoneNumberEmailGateWay|#" (Puts specific PhoneNumber SMS GateWay onto admin list)')
                                print("sent")
                            case "openprogram":
                                openProgram(RawData[1], RawData[2], RawData[3])
                                ezgmail.send(j.sender, 'Registered', 'Automater Has run "openProgram"')
                            case "allow":
                                try:
                                    RawData[1] = midSplit(RawData[1],"&lt;", "&gt;")
                                except:
                                    pass    
                                Allow(RawData[1], False, False)
                                ezgmail.send(RawData[1], 'Registered', 'You have been verified, You may now try your command again')
                            case "adminallow":
                                try:
                                    RawData[1] = midSplit(RawData[1],"&lt;", "&gt;")
                                except:
                                    pass
                                if (RawData[2] == "#"):
                                    Allow(RawData[1], True, True)
                                else:
                                    Allow(RawData[1], True, False)
                                ezgmail.send(RawData[1], 'Registered', 'Your admin certificate have been verified')
                            case "getaddress":
                                AddressData ='Automater Has run "getAddress"\n' + GetData(RawData[1], RawData[2])
                                ezgmail.send(j.sender, 'Registered', AddressData)
                            case "getadminlist":
                                AddressData ='Automater Has run "getAdminList"\n'
                                for i in getAdminList(RawData[1]=="#"):
                                    AddressData+= "%s\n" % (i)
                                ezgmail.send(j.sender, 'Registered', AddressData)
                            case "addaddress":
                                AddressData ='Automater Has run "AddAddress"\n' + insert(RawData[1])
                                ezgmail.send(j.sender, 'Registered', AddressData)
                            case "introduce":
                                ezgmail.send(RawData[1], 'Hi! I\'m Helper!', 'I am an automated email computing and data retrieval tool created by Aiden Thomas inorder to help with the sending of data.\
                                             \n If you wish to send your first command and learn more about what I have to offer, you can:\
                                             \n Email this email address with the subject line "helper", and in the main body just write "help".\
                                             \n *Warning, I could be offline for maintnance from 10pm EST to 7am EST (Maybe More)*')
                                print("sent")
                        ezgmail.markAsRead(l)
                elif (j.subject == "Helper" or j.subject == "helper"):
                        RawData = j.snippet
                        RawData = str(RawData)
                        RawData = RawData.split(";")
                        print(RawData)
                        match RawData[0].lower():
                            case "introduce":
                                ezgmail.send(j.sender, 'Hi! I\'m Helper!', 'I am an automated email computing and data retrieval tool created by Aiden Thomas inorder to help with the sending of data.\
                                             \n If you wish to send your first command and learn more about what I have to offer, you can:\
                                             \n Email this email address with the subject line "helper", and in the main body just write "help".\
                                             \n *Warning, I could be offline for maintnance from 10pm EST to 7am EST (Maybe More)*')
                                print("sent")
                            case "help":
                                ezgmail.send(j.sender, 'Registered', 'Helper Has These Special Commands Currently: \
                                             \n1. Get the current resume: "GetResume;"\
                                             \n2. Get available information: "GetInfo;"\
                                             \n3. Contact the creator: "Contact;(your message);\
                                             \n4. Get helpers introduction: "introduce;"')
                                print("sent")
                            case "getresume" :
                                if (verAllow(midSplit(j.sender,"<", ">"), False)):
                                    try:
                                        ezgmail.send(j.sender, 'Registered', 'Helper has run "GetResume"\n Please try again if an issue occured ', "MailAutomater/Thomas, Aiden resume 3.0.1.pdf")
                                    except:
                                        ezgmail.send(j.sender, 'Registered', 'Helper has run "GetResume"\n Please try again if an issue occured ', "Thomas, Aiden resume 3.0.1.pdf")
                                else:
                                    ezgmail.send(j.sender, 'You aren\'t on the list', 'Please hold while my creator verifies your request')
                                    AdminList = getAdminList(True)
                                    for i in AdminList:
                                        if (i!=None):
                                            ezgmail.send(i, 'Message from Automater', str(j.sender+" Requests for you to allow them access to "+RawData[0]))
                                    AdminList = getAdminList(False)
                                    for i in AdminList:
                                        if (i!=None):
                                            ezgmail.send(i,'Message from Automater', str("Send email to Automater: Allow|"+j.sender))
                            case "contact":
                                ezgmail.send("3218316162@txt.att.net", 'Message from Automater', str(j.sender+" has sent a direct email to you!"))
                                ezgmail.send("aidenthomas711@gmail.com",'Message from Automater', str(j.sender+" sent:\n"+RawData[1]))
                                ezgmail.send(j.sender, 'Registered', "Sent your message!\n My creator will get back to you as soon as he can!")
                            case "getinfo":
                                ezgmail.send(j.sender, 'Registered', 'Helper has run "GetInfo"\
                                             \n Creator: Aiden Thomas\
                                             \n LinkedIn: https://www.linkedin.com/in/aiden-thomas-93002624a/', 'Creator.jpg')
                        ezgmail.markAsRead(l)
                ezgmail.markAsRead(l)

if __name__ == '__main__':
    ezgmail.init()
    print("Running")
    while(True):
        Run()
        