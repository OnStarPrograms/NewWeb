import keyboard
import time

def FixCaseError(Str,Case,Replace):
            nProgram = Str.split(Case)
            Str = ""
            for i in nProgram:
                Str+=i+Replace
            return Str

def midSplit(str, Split1, Split2):
    a = str.split(Split1)
    a = a[1]
    a = a.split(Split2)
    return a[0]

def openProgram(ext,name,Program):
    Program = str(Program)
    Program = FixCaseError(Program,"“",'"')
    Program = FixCaseError(Program,"”",'"')
    Program = FixCaseError(Program,"&#39;","'")
    Program = FixCaseError(Program,"&#39;","'")
    Program = Program.split('""\'\'')
    Program = Program[0].split("$")
    print(Program)
    keyboard.press_and_release('control+alt+windows+n')
    keyboard.write(name)
    keyboard.write(ext)
    keyboard.press_and_release("enter")
    time.sleep(1)
    keyboard.press_and_release("enter")
    time.sleep(1)
    for i in Program:
        if (i[0] == "~"):
           keyboard.press_and_release("backspace")
           i = i.split("~")
           keyboard.write(i[1])
        elif (i[0] == "^"):
           keyboard.press_and_release("tab")
           i = i.split("^")
           keyboard.write(i[1])
        else:
            keyboard.write(i)
        keyboard.write("\n")
    time.sleep(1)
    keyboard.press_and_release("control+s")
    time.sleep(1)
    keyboard.press_and_release("enter")

def BuildPersonalTimer(Username):
     Ab = "import win32com.client\nimport pythoncom\nimport os\nimport pathlib\nMypath = r'C:\\Users\\'"
     Ba = "\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Startup\\AlarmClock.lnk'\ntarget = pathlib.Path(__file__).parent.resolve()\nicon = os.path.join(target, 'Alarm.ico')\ntarget = os.path.join(target, 'AlarmClock.exe')\nshell = win32com.client.Dispatch('WScript.Shell')\nshortcut = shell.CreateShortCut(Mypath)\nshortcut.Targetpath = target\nshortcut.IconLocation = icon\nshortcut.WindowStyle = 7 # 7 - Minimized, 3 - Maximized, 1 - Normal\nshortcut.save()"